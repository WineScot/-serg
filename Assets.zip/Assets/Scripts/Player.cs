﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    private int healthLevel = 100;
    private int maxhealthLevel = 100;
    private int magicLevel = 1000;
    private int baseAttack = 40;
    private int armorLevel = 10;

    public void TakeHealthPoint(int attackPoints) // this function take hero health point
    {
        attackPoints -= armorLevel;
        if (attackPoints > 0)
        {
            healthLevel -= attackPoints;
        }
        if (healthLevel <= 0)
        {
            //event when we die
        }
    }

    public void Cure(bool totally, int curyPoints) // this function cure hero
    {
        if (totally) // if we want cure hero totally
        {
            healthLevel = maxhealthLevel;
        }
        else // if we want cure hero incompletly
        {
            healthLevel += curyPoints;
            if (healthLevel > maxhealthLevel) healthLevel = maxhealthLevel;
        }
    }

    // Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
