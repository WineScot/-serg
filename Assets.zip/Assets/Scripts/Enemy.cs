﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    private Rigidbody2D rb2d;

    public int healthLevel = 100;
    private int maxhealthLevel = 1000;
    private int magicLevel = 1000;
    private int baseAttack = 40;
    private int armorLevel = 0;
    private int cureQuick = 10;
    public bool onAttack = false; // true - when Enemy is attacking

    public void TakeHealthPoint(int attackPoints) // this function take hero health point
    {
        
        attackPoints -= armorLevel;
        if (attackPoints > 0)
        {
            healthLevel -= attackPoints;
        }
        if (healthLevel <= 0)
        {
            Destroy(gameObject);
        }
        onAttack = true; // onAttack block motion in EnemyDetection
        Vector2 movement = new Vector2(50, 30); // gdy zaatakujemy wróg odskakuje na bok
        rb2d.velocity = movement;
        Invoke("OnAttackFalse", 2); // evokes funcion after 2 seconds
    }

    public void OnAttackFalse() // unlock motion in EnemyDetection
    {
        onAttack = false;
    }


	// Use this for initialization
	void Start () 
    {
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
