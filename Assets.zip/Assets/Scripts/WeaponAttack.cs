﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponAttack : MonoBehaviour {

    public bool intrigger = false;
    private int attackPoint = 20;
    void OnTriggerStay2D(Collider2D other)
    {
        intrigger = true;
        if (other.tag == "Enemy")
        {
            
            other.gameObject.GetComponent<Enemy>().TakeHealthPoint(attackPoint);
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        intrigger = false;
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
