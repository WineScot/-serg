﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpearThrowing : MonoBehaviour {

    private Rigidbody2D rb2d;
    private bool isThrowing = true;
    private bool isFlying = false;
    private float gravityScale;
    private Vector2 size = new Vector2(3f, 3f);

    public float scale = 0.5f;

	// Use this for initialization
	void Start () {

        rb2d = GetComponent<Rigidbody2D>();
        gravityScale = rb2d.gravityScale;
        rb2d.gravityScale = 0;
	}

	// Update is called once per frame
	void Update ()
    {
		
        if(isThrowing)
        {
            Vector3 mouseScreenPosition = new Vector3(Input.mousePosition.x, Input.mousePosition.y, -Camera.main.transform.position.z);
            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);
            Vector2 spearPosition = rb2d.gameObject.transform.position;
            spearPosition -= size;
            Vector2 vel = spearPosition - mousePosition;

            float angle = Mathf.Atan2(vel.y, vel.x) - transform.rotation.z;

            transform.Rotate(0, 0, angle * Time.deltaTime * 1000);

            if (Input.GetMouseButtonDown(0))
            {
                vel += size;
                rb2d.gravityScale = gravityScale;
                vel *= scale;
                rb2d.velocity = vel;
                isThrowing = false;
                isFlying = true;
            }
        }
        /*else if(Input.GetKeyDown("A"))
        {
            isThrowing = true;
        }*/
	}

    void OnTriggerEnter2D(Collider2D collision)
    {
        rb2d.gravityScale = 0;
        rb2d.velocity = new Vector2(0, 0);
    }
}
